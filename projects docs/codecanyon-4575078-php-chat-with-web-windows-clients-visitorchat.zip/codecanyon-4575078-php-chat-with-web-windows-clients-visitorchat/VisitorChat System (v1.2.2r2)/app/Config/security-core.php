<?php

Configure::write('Security.salt', 'fYvn2a7G3Ry852ocj20J803q5l942kOiFEzyDKJk');
Configure::write('Security.cipherSeed', '36084619963166514593845504613');

