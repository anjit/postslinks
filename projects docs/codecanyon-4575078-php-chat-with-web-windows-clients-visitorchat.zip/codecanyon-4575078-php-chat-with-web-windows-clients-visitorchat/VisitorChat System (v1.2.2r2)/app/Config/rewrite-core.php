<?php

/**
 * If mod_rewrite is not enabled/installed on your server,
 * please uncomment the line below this comment (line 16).
 * 
 * In this case you will also need to delete or 
 * rename the following three files:
 * 
 * ROOT\.htaccess
 * ROOT\app\.htaccess
 * ROOT\app\webroot\.htaccess
 * 
 */

 //Configure::write('App.baseUrl', env('SCRIPT_NAME'));