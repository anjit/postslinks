<?php

class AppVersion
{

    const Version = '1.2.2';

}