<?php
$map = array(
	1 => array('001_schema_dump' => 'M4af6d40056b04408808500cb58157726')
);
?>