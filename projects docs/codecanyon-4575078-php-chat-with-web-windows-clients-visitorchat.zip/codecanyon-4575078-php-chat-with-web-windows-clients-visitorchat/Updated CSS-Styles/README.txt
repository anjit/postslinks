If you are updating from an earlier version, you can use the CSS-Styles 
in this directory to update the default styles.

Simply paste them in the respective Chat-Style and hit "Save".

You do not need these files if you are installing VisitorChat for the first time.