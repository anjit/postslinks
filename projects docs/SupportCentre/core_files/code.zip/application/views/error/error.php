<div class="container marginTop">
	<div class="row">
        <div class="col-md-12">
			<div class="page-header-block-error top-rounded-corners lightShadow">
				<div class="page-header-icon"><img src="<?php echo base_url() ?>images/icons/document_24_white.png" alt="content"></div><div class="page-header-title"><?php echo lang("content_error_title") ?></div>
				<div class="clearfix"></div>
			</div>
			<div class="block-normal bot-rounded-corners lightShadow">
				<div class="block-content-main">
				<div class="align-center decent-margin"><img src="<?php echo base_url() ?>images/icons/lock_64.png" alt="content"><br /><b><?php echo lang("content_error_msg") ?></b>: <?php echo $message ?></div>
</div>
			</div>
		</div>
	</div>
</div>