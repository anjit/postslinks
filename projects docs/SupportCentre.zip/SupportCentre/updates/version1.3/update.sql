ALTER TABLE site_settings
ADD alert_support_staff int(11)