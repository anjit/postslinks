ALTER TABLE tickets
ADD notes TEXT